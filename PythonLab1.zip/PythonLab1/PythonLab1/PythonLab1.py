# Выполнил: студент 24-ИСТ-3 Лапин Л. Д.
# Сортировка по возрастанию длины слов в строке.
# Примечание: Чтение из файла или с клавиатуры.

import re
import string

def swbl():
    
    char4del = '.,!?;:"()[]{}«»—–' + string.punctuation + string.digits # символы, которые мы не будем учитывать при подсчете длины слова
    rezh = ''                                                           # выбор режима работы программы

    while rezh not in ['1', '2']:
        rezh = input("Выберите способ ввода (1 - ввод с клавиатуры; 2 - чтение из файла): ")

        if rezh == '1':  # ввод с клавиатуры
            text = input("Введите строку: ")

        elif rezh == '2':  # чтение из файла
            filename = "C:/Users/user/source/repos/PythonLab1/text.txt"
            try:
                with open(filename, 'r', encoding='utf-8') as file:
                    text = file.read()
            except FileNotFoundError:
                print(f"Ошибка: Файл '{filename}' не найден.")
                return
            except Exception as e:
                print(f"Произошла ошибка: {e}")
                return
        else:
            print("Неверный выбор. Попробуйте еще раз!")
    
    pattern = '[' + re.escape(char4del) + ']'
    goodText = re.sub(pattern, ' ', text)

    words = [word for word in goodText.split() if word]

    if not words:  # на случай, если не осталось слов после очистки
        print("В тексте нет слов для сортировки.")
        return

    furstIter = sorted(words, key=len)
    secondIter = set()
    thirdIter = []
    

    for word in furstIter:
        loWord = word.lower()
        if loWord not in secondIter:
            secondIter.add(loWord)
            thirdIter.append(f"{loWord} ({len(loWord)} символов)")

    for i, item in enumerate(thirdIter, 1):
        print(f"{i}. {item}")

swbl()