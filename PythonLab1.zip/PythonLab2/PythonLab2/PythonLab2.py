"""
Выполнил: студент 24-ИСТ-3 Лапин Л. Д.
0.	Дано: Wave-файл в соответствии с таблицей №1.  В файле находится отрезок звукового сигнала, 
который можно прослушать любой аудио-программой. 
Номер варианта равен порядковому номеру студента в списке группы.
1.	Задание: 
Составить программу на Python, которая реализует:
1.1	Чтение из wav-файла дискретных отсчетов звукового сигнала и визуализация полученных данных 
в соответствии с типом графика Таблицы №1. 
Можно визуализировать, например, только первые 100 отсчетов звукового сигнала.
1.2	Построение осциллограммы звукового сигнала, находящегося в wav-файле, как функции времени.
1.3	Спектральный анализ всех дискретных отсчетов звукового сигнала, находящихся в wav-файле 
в соответствии с типом спектрального анализа Таблицы №1. 
Построение графика результата спектрального анализа в зависимости от частоты. 
1.4	 Построение гистограммы отсчетов звукового сигнала (количество или частота попадания значений 
отсчетов сигнала в определенный амплитудный интервал)
1.5	Все графики и оси координат должны быть ОБЯЗАТЕЛЬНО подписаны и проставлена размерность 
по горизонтали: в секундах или в Герцах.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from scipy.fft import fft

try:
    rate, aData = wavfile.read("C:/Users/user/source/repos/PythonLab2/17.wav")
except FileNotFoundError:
    print("Ошибка: Файл не найден по указанному пути.")
    exit()

if aData.ndim > 1:      # при стерео один канал
    aData = aData[:, 0]

# Лепестковая диаграмма
steps = aData[:100] # замер амплидут сигнала
angles = np.linspace(0, 2 * np.pi, len(steps), endpoint=False).tolist() # углы диаграммы
steps = np.append(steps, steps[0]) # замыкание круга
angles = angles + angles[:1]

plt.figure(figsize=(10, 8))
ax = plt.subplot(111, projection='polar')
ax.plot(angles, steps, 'o-', linewidth=2)
ax.set_title('Лепестковая диаграмма первых 100 отсчётов звукового сигнала', pad=20)
ax.set_ylabel('Амплитуда')
plt.show()

# Осциллограмма
time = np.arange(len(aData)) / rate  # время (секунды)

plt.figure(figsize=(12, 6))
plt.plot(time, aData)
plt.title('Осциллограмма звукового сигнала')
plt.xlabel('Время, с')
plt.ylabel('Амплитуда')
plt.grid(True)
plt.show()

# График спектра
spectrum = fft(aData) # ДПФ
powSpec = np.abs(spectrum) ** 2 # квадрат модуля: Re**2+Jm**2
freq = np.fft.fftfreq(len(aData), 1 / rate) # частотная ось

halFreq = len(freq) // 2
posFreq = freq[:halFreq]
powSpecPos = powSpec[:halFreq]

plt.figure(figsize=(12, 6))
plt.plot(posFreq, powSpecPos)
plt.title('Спектральный анализ: квадрат модуля ДПФ')
plt.xlabel('Частота, Гц')
plt.ylabel('Мощность (|X(f)|**2)')
plt.grid(True)
plt.show()

# Гистограмма отсчётов сигнала
plt.figure(figsize=(10, 6))
plt.hist(aData, bins=100, edgecolor='black')
plt.title('Гистограмма распределения амплитуд звукового сигнала')
plt.xlabel('Амплитуда')
plt.ylabel('Количество отсчётов')
plt.grid(True, alpha=0.3)
plt.show()
