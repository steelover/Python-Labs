from PIL import Image

def decode(encodeImage, keysFile): # декодирование заданного изображения
    img = Image.open(encodeImage).convert('RGB')
    pixels = img.load()
    width, height = img.size

    keys = []
    with open(keysFile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            x, y = map(int, line.replace('(', '').replace(')', '').split(', ')) # вытаскиваем координаты из ключа
            keys.append((x, y))

    message = ""
    for x, y in keys:
        if 0 <= x < width and 0 <= y < height: # диапазон значений координат
            blue_value = pixels[x, y][2]
            if 0 <= blue_value <= 255: # символ сообщения очевидно в диапазоне ASCII от 0 до 255
                message += chr(blue_value)
    return message

def encode(encodedImage, message, keysFile): # кодирование заданного изображения
    img = Image.open(encodedImage).convert('RGB')
    pixels = img.load()
    width, height = img.size

    keys = []
    with open(keysFile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            x, y = map(int, line.replace('(', '').replace(')', '').split(', '))
            keys.append((x, y))

    message_bits = ''.join(format(ord(char), '08b') for char in message) # подготовка битов сообщения

    print("Биты первого символа текстового сообщения:")
    if message:
        print(f"{message_bits[:8]} (символ: {message[0]})")
    else:
        print("Сообщение пустое")

    for idx, (x, y) in enumerate(keys):     # кодирование
        if idx * 2 >= len(message_bits):    # если биты закончились
            break
        if not (0 <= x < width and 0 <= y < height):  # проверка границ
            continue

        rBit = message_bits[idx * 2]
        gBit = message_bits[idx * 2 + 1]

        # Исходные значения
        rOrig, gOrig, bOrig = pixels[x, y]
        print(f"\nИсходные значения пикселей [{x}, {y}]: R={rOrig}, G={gOrig}, B={bOrig}")

        # Меняем 0‑й бит R и G
        rNew = (rOrig & 0xFE) | int(rBit)
        gNew = (gOrig & 0xFE) | int(gBit)
        pixels[x, y] = (rNew, gNew, bOrig)
        print(f"Изменённые значения пикселей: R={rNew}, G={gNew}, B={bOrig}")

    # Сохраняем результат
    img.save("encoded_image.png")
    print("\nИзображение с закодированным сообщением сохранено как 'encoded_image.png'")

def decodeEncode(encodedImage, keysFile): # декодирование закодированного изображения
    img = Image.open(encodedImage).convert('RGB')
    pixels = img.load()
    width, height = img.size

    keys = []
    with open(keysFile, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                x, y = map(int, line.replace('(', '').replace(')', '').split(', '))
                keys.append((x, y))
            except:
                continue

    messageBits = ""
    for x, y in keys:
        if 0 <= x < width and 0 <= y < height:
            rVal, gVal, _ = pixels[x, y]
            messageBits += str(rVal & 1)  # 0‑й бит R
            messageBits += str(gVal & 1)  # 0‑й бит G

    message = "" # создание текста сообщения
    for i in range(0, len(messageBits), 8):
        byte = messageBits[i:i+8]
        if len(byte) == 8:
            message += chr(int(byte, 2))
    return message

image = "C:/Users/user/source/repos/PythonLab3/new17.png"
keyFile = "C:/Users/user/source/repos/PythonLab3/keys17.txt"

print("Декодирование сообщения: ")
decodeMsg = decode(image, keyFile)
print("Скрытое сообщение: ", decodeMsg)

print("\nКодирование и демонстрация: ")
demoMsg = "Пример сообщения"
encode(image, demoMsg, keyFile)

print("\nПроверка декодирования: ")
retrievMsg = decodeEncode("encoded_image.png", keyFile)
print("Восстановленное сообщение: ", retrievMsg)